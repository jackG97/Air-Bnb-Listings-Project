Folder: Code Mapreduce

When you open the folder you will find 4 folders named:

CharCount london summarisation
CharCount New York Summarisation
Input-Output Pattern London dataset
Input-Output Pattern New York dataset

in these folders contains the following:

the text files with outputs produced. 
the mapper and redcuer files with the python code. it was ran through notepadd++.
the bat file with the commands to run the command prompt. 
all folders contain the datset i was working off. 
there are also folders that contain screenshots of the different types analysis i performed

the files you see named Combined.txt contains the dataset values combined after the mapreduce functions were perfomred.

Folder: Code R

this folder contains 2 R project files where i ran the R code for both datasets to perform my other analysis. 
it also contains the 2 datasets. 
and two folders that have screenshots of the different analysis that i performed using R.

when you open both R project files, there is a section of code that goes from line 1 to 61 in both R files
this is initialising the dataset and backing it up. it must be ran first. afterwards you then run the rest of the code to see the analysis being performed.